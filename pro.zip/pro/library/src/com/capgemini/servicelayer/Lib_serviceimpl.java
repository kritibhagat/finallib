package com.capgemini.servicelayer;

import com.capgemini.dto.Lib_dto;

import com.capgemini.librarian.dao.Libra_impl;
import com.capgemini.exception.FilenotfoundException;
import com.capgemini.librarian_dto.Addview_book;
import com.capgemini.librarian_dto.Del_book;
import com.capgemini.librarian_dto.Reg_user;
import com.capgemini.dao.Lib_daoimpl;
import java.sql.SQLException;

public class Lib_serviceimpl implements Lib_service {

	
	private Lib_daoimpl dao= new Lib_daoimpl();
	private Libra_impl dao2= new Libra_impl();
	public int Insertissuedetails(Lib_dto dto) throws FilenotfoundException,SQLException,ClassNotFoundException
	{
		
		int g = dao.Insertissuedetails(dto);
		return g;
	
		
	}
    public void returnbook(Lib_dto del) throws FilenotfoundException,SQLException,ClassNotFoundException
    {
    	
   dao.returnbook(del);
    }
    
    
    public int Addview (Addview_book ad) throws FilenotfoundException,SQLException,ClassNotFoundException{
    	
    	int add= dao2.Addview(ad);
    	return add;
    	
    }
    public void Delete(Del_book db) throws FilenotfoundException,SQLException,ClassNotFoundException{}
    public void Register(Reg_user ru) throws FilenotfoundException,SQLException,ClassNotFoundException{
    	
    	dao2.Register(ru);
    	
    }
   	    
}
